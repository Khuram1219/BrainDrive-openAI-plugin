module.exports = {
	plugins: {
		autoprefixer: {},
	},
};
